Готовый пакет сайта-портфолио для GitHub Pages.

Что загрузить в репозиторий CGskills/alexey-portfolio:
- index.html
- styles.css
- папку assets/
- папку videos/
- .nojekyll

Как загрузить:
1) Открой репозиторий: https://github.com/CGskills/alexey-portfolio
2) Нажми Add file -> Upload files
3) Перетащи ВСЕ файлы и папки из этой папки
4) Если GitHub спросит про замену, подтверждай Replace
5) Commit changes
6) Убедись, что в Settings -> Pages включено: Deploy from a branch -> main /(root)

После публикации сайт будет доступен по адресу:
https://cgskills.github.io/alexey-portfolio/
