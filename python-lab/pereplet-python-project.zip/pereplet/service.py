from domain import calculate_total, Repo

class CheckoutService:
    def __init__(self, repo: Repo):
        self.repo = repo

    def place(self, order_id, prices):
        total = calculate_total(prices)
        self.repo.save(order_id, total)
        return total
