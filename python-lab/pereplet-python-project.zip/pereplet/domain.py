from typing import Protocol

class Repo(Protocol):
    def save(self, order_id: str, amount: int) -> None: ...

def calculate_total(prices):
    if any(price < 0 for price in prices):
        raise ValueError("Цена не может быть отрицательной")
    return sum(prices)
