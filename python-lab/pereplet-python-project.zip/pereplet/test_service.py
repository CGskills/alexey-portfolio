from service import CheckoutService

class FakeRepo:
    def __init__(self):
        self.saved = []
    def save(self, order_id, amount):
        self.saved.append((order_id, amount))

def test_place():
    repo = FakeRepo()
    service = CheckoutService(repo)
    assert service.place("A", [180, 120]) == 300
    assert repo.saved == [("A", 300)]
