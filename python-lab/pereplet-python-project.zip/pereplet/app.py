from service import CheckoutService
from repository import MemoryRepo

repo = MemoryRepo()
service = CheckoutService(repo)

# Интерфейс передаёт данные сервису
result = service.place("A-01", [180, 120])
print(f"К оплате: {result} ₽")
