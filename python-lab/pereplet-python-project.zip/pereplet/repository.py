class MemoryRepo:
    def __init__(self):
        self._orders = {}

    def save(self, order_id, amount):
        self._orders[order_id] = amount

    def get(self, order_id):
        return self._orders.get(order_id)
